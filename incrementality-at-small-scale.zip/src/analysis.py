"""True-lift analysis on the Criteo Uplift dataset.

Produces the four headline measurements for the dashboard:
  1. Ads drive real, measurable lift            (randomized intent-to-treat lift + CI)
  2. Attribution and true lift measure different things
                                                (exposed-vs-unexposed comparison vs randomized lift)
  3. A clear read takes scale                   (users needed for a statistically clear result)
  4. Lift concentrates in persuadable users     (uplift model, decile breakdown, Qini)
plus credibility checks: covariate balance, A/A placebo tests.

Usage:
    python src/analysis.py --data data/criteo_uplift.pkl --out outputs/
"""
import argparse
import json
import os
import time

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import HistGradientBoostingClassifier, HistGradientBoostingRegressor
from sklearn.model_selection import train_test_split

FEATURES = [f"f{i}" for i in range(12)]
Z = stats.norm.ppf(0.975)


# ---------- 1. Randomized lift ----------
def diff_in_proportions(y_t, n_t, y_c, n_c):
    """Absolute lift, relative lift, 95% CI (abs) and p-value for two proportions."""
    p_t, p_c = y_t / n_t, y_c / n_c
    d = p_t - p_c
    se = np.sqrt(p_t * (1 - p_t) / n_t + p_c * (1 - p_c) / n_c)      # unpooled SE for the CI
    p_pool = (y_t + y_c) / (n_t + n_c)                                  # pooled SE for the test (better calibrated
    se0 = np.sqrt(p_pool * (1 - p_pool) * (1 / n_t + 1 / n_c))          # when one arm has very few events)
    z = d / se0 if se0 > 0 else 0.0
    return {
        "rate_treated": p_t, "rate_control": p_c,
        "lift_abs": d, "lift_rel": d / p_c if p_c else np.nan,
        "ci_abs": [d - Z * se, d + Z * se],
        "ci_rel": [(d - Z * se) / p_c, (d + Z * se) / p_c] if p_c else [np.nan, np.nan],
        "z": z, "p_value": 2 * (1 - stats.norm.cdf(abs(z))),
    }


def randomized_lift(df, outcome):
    t, c = df[df.treatment == 1], df[df.treatment == 0]
    r = diff_in_proportions(t[outcome].sum(), len(t), c[outcome].sum(), len(c))
    r["n_treated"], r["n_control"] = len(t), len(c)
    r["incremental"] = r["lift_abs"] * len(t)                  # outcomes caused by ads in treated group
    r["incremental_share"] = r["incremental"] / t[outcome].sum()  # share of treated-group outcomes that were incremental
    return r


# ---------- 2. Attribution-style comparison ----------
def attribution_view(df, outcome, itt):
    """Exposed vs unexposed (treated users only). Exposure is not random, so this
    mixes the ad's effect with differences in WHO gets shown ads (selection)."""
    t = df[df.treatment == 1]
    exp, unexp = t[t.exposure == 1], t[t.exposure == 0]
    naive = diff_in_proportions(exp[outcome].sum(), len(exp), unexp[outcome].sum(), len(unexp))
    exposure_rate = len(exp) / len(t)
    # Effect per exposed user via the Wald / instrumental-variable estimator (treatment as instrument)
    cace = itt["lift_abs"] / exposure_rate
    return {
        "exposure_rate_treated": exposure_rate,
        "rate_exposed": naive["rate_treated"], "rate_unexposed": naive["rate_control"],
        "naive_lift_rel": naive["lift_rel"],
        "attributed_outcomes": int(exp[outcome].sum()),       # 'counted' if every exposed outcome is credited
        "incremental_outcomes": float(itt["incremental"]),
        "attributed_to_incremental_ratio": exp[outcome].sum() / itt["incremental"] if itt["incremental"] > 0 else np.nan,
        "effect_per_exposed_user_abs": cace,
        "effect_per_exposed_user_rel": cace / naive["rate_control"] if naive["rate_control"] else np.nan,
    }


# ---------- Credibility checks ----------
def covariate_balance(df):
    """Standardized mean difference per feature (|SMD| < 0.1 is the usual 'balanced' bar)."""
    t, c = df[df.treatment == 1], df[df.treatment == 0]
    out = {}
    for f in FEATURES:
        pooled = np.sqrt((t[f].var() + c[f].var()) / 2)
        out[f] = float((t[f].mean() - c[f].mean()) / pooled) if pooled > 0 else 0.0
    return out


def aa_placebo(df, outcome, runs, rng):
    """Split the CONTROL group randomly into two fake arms many times. No ad differs between them,
    so ~5% of runs should be 'significant' at p<0.05 if the method is calibrated."""
    y = df.loc[df.treatment == 0, outcome].to_numpy()
    n = len(y)
    lifts, sig = [], 0
    for _ in range(runs):
        m = rng.random(n) < 0.5
        r = diff_in_proportions(y[m].sum(), m.sum(), y[~m].sum(), (~m).sum())
        lifts.append(r["lift_rel"])
        sig += r["p_value"] < 0.05
    return {"runs": runs, "mean_lift_rel": float(np.mean(lifts)), "false_positive_rate": sig / runs}


# ---------- 3. A clear read takes scale ----------
def users_needed(p_c, lift_abs, holdout, power=0.8, alpha=0.05):
    """Total users needed to detect lift_abs with given power, for a given holdout share."""
    za, zb = stats.norm.ppf(1 - alpha / 2), stats.norm.ppf(power)
    p_t = p_c + lift_abs
    var = p_t * (1 - p_t) / (1 - holdout) + p_c * (1 - p_c) / holdout
    return (za + zb) ** 2 * var / lift_abs ** 2


def power_curve(df, outcome, itt, sizes, holdouts, sims, rng):
    """Analytic users-needed per holdout share, plus an empirical check: draw random
    'advertisers' of each size from the data and count how often the lift is significant."""
    analytic = {f"{h:.0%}": users_needed(itt["rate_control"], itt["lift_abs"], h) for h in holdouts}
    t_idx = np.flatnonzero(df.treatment.to_numpy() == 1)
    c_idx = np.flatnonzero(df.treatment.to_numpy() == 0)
    y = df[outcome].to_numpy()
    rows = []
    for h in holdouts:
        for n in sizes:
            n_c = int(n * h); n_t = n - n_c
            if n_c > len(c_idx) or n_t > len(t_idx):
                continue
            sig, widths = 0, []
            for _ in range(sims):
                # sampling with replacement: negligible difference at these sizes, much faster on 14M rows
                yt = y[t_idx[rng.integers(0, len(t_idx), n_t)]]
                yc = y[c_idx[rng.integers(0, len(c_idx), n_c)]]
                r = diff_in_proportions(yt.sum(), n_t, yc.sum(), n_c)
                sig += (r["p_value"] < 0.05) and (r["lift_abs"] > 0)
                widths.append(r["ci_rel"][1] - r["ci_rel"][0])
            rows.append({"holdout": h, "users": n, "share_clear_reads": sig / sims,
                         "median_ci_width_rel": float(np.median(widths))})
    return analytic, pd.DataFrame(rows)


# ---------- 4. Lift concentrates in persuadable users ----------
def fit_scores(train, test, outcome, seed):
    """Fit two uplift learners on train, return held-out uplift scores for each.
    T-learner: separate outcome models for treated and control; uplift = difference.
    X-learner (Kunzel et al. 2019): imputes each user's individual effect using the OTHER arm's model,
    then models those effects directly. Designed for unbalanced arms like this 85/15 split."""
    params = dict(max_iter=200, learning_rate=0.1, max_leaf_nodes=31, l2_regularization=1.0,
                  early_stopping=True, random_state=seed)
    tr_t, tr_c = train[train.treatment == 1], train[train.treatment == 0]
    m_t = HistGradientBoostingClassifier(**params).fit(tr_t[FEATURES], tr_t[outcome])
    m_c = HistGradientBoostingClassifier(**params).fit(tr_c[FEATURES], tr_c[outcome])
    scores = {"t_learner": m_t.predict_proba(test[FEATURES])[:, 1] - m_c.predict_proba(test[FEATURES])[:, 1]}

    d1 = tr_t[outcome] - m_c.predict_proba(tr_t[FEATURES])[:, 1]     # treated: observed - predicted no-ad outcome
    d0 = m_t.predict_proba(tr_c[FEATURES])[:, 1] - tr_c[outcome]     # control: predicted ad outcome - observed
    tau1 = HistGradientBoostingRegressor(**params).fit(tr_t[FEATURES], d1)
    tau0 = HistGradientBoostingRegressor(**params).fit(tr_c[FEATURES], d0)
    g = train.treatment.mean()                                        # randomized: propensity is constant
    scores["x_learner"] = g * tau0.predict(test[FEATURES]) + (1 - g) * tau1.predict(test[FEATURES])
    return scores


def qini(test, score, outcome):
    s = test.assign(_s=score).sort_values("_s", ascending=False)
    tr = s.treatment.to_numpy(); y = s[outcome].to_numpy()
    cum_t, cum_c = np.cumsum(tr), np.cumsum(1 - tr)
    cum_yt, cum_yc = np.cumsum(y * tr), np.cumsum(y * (1 - tr))
    with np.errstate(divide="ignore", invalid="ignore"):
        q = cum_yt - np.where(cum_c > 0, cum_yc * cum_t / cum_c, 0)
    frac = np.arange(1, len(s) + 1) / len(s)
    rand = frac * q[-1]
    coef = float(np.trapezoid(q - rand, frac) / max(abs(q[-1]), 1e-9))
    return coef, frac, q, rand


def uplift_model(df, outcome, rng_seed, model_rows):
    """Compare T- and X-learners on held-out users; report deciles for the better one (by Qini)."""
    d = df.sample(n=min(model_rows, len(df)), random_state=rng_seed) if model_rows else df
    train, test = train_test_split(d, test_size=0.5, random_state=rng_seed, stratify=d.treatment)
    test = test.copy()
    scores = fit_scores(train, test, outcome, rng_seed)
    comparison = {name: qini(test, s, outcome)[0] for name, s in scores.items()}
    best = max(comparison, key=comparison.get)
    test["uplift_score"] = scores[best]

    # Deciles by predicted uplift (1 = most persuadable); observed uplift computed per decile
    test["decile"] = pd.qcut(test.uplift_score.rank(method="first", ascending=False), 10, labels=range(1, 11))
    rows = []
    for dec, g in test.groupby("decile", observed=True):
        t, c = g[g.treatment == 1], g[g.treatment == 0]
        r = diff_in_proportions(t[outcome].sum(), len(t), c[outcome].sum(), len(c))
        rows.append({"decile": int(dec), "users": len(g), "rate_treated": r["rate_treated"],
                     "rate_control": r["rate_control"], "uplift_abs": r["lift_abs"],
                     "ci_low": r["ci_abs"][0], "ci_high": r["ci_abs"][1],
                     "incremental_per_1k": r["lift_abs"] * 1000})
    dec = pd.DataFrame(rows)
    pos = dec.uplift_abs.clip(lower=0) * dec.users
    dec["share_of_incremental"] = pos / pos.sum()

    # Qini curve: cumulative incremental outcomes when targeting users in model order
    qini_coef, frac, q, random_line = qini(test, test.uplift_score, outcome)
    pts = np.linspace(0, len(test) - 1, 21).astype(int)
    qini_df = pd.DataFrame({"share_targeted": frac[pts], "model": q[pts], "random": random_line[pts]})

    top30 = dec[dec.decile <= 3]
    targeting = {
        "top30_incremental_per_1k": float((top30.uplift_abs * top30.users).sum() / top30.users.sum() * 1000),
        "all_incremental_per_1k": float((dec.uplift_abs * dec.users).sum() / dec.users.sum() * 1000),
    }
    targeting["top30_vs_all_multiple"] = targeting["top30_incremental_per_1k"] / targeting["all_incremental_per_1k"]
    return dec, qini_df, {"learner": best, "qini_by_learner": comparison,
                          "qini_coefficient": qini_coef, "top20_share_of_incremental":
                          float(dec.loc[dec.decile <= 2, "share_of_incremental"].sum()),
                          "test_rows": len(test), **targeting}


def to_jsonable(o):
    if isinstance(o, dict): return {k: to_jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)): return [to_jsonable(v) for v in o]
    if isinstance(o, (np.floating, np.integer)): return o.item()
    return o


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/criteo_uplift.pkl")
    p.add_argument("--out", default="outputs")
    p.add_argument("--seed", type=int, default=7)
    p.add_argument("--aa-runs", type=int, default=200)
    p.add_argument("--power-sims", type=int, default=200)
    p.add_argument("--model-rows", type=int, default=4_000_000, help="rows used for uplift model (0 = all)")
    p.add_argument("--uplift-outcome", default="visit", help="visit has ~15x more signal than conversion")
    a = p.parse_args()
    rng = np.random.default_rng(a.seed)
    os.makedirs(a.out, exist_ok=True)
    t0 = time.time()

    df = pd.read_pickle(a.data)
    m = {"rows": len(df), "treated_share": float(df.treatment.mean())}

    m["lift"] = {o: randomized_lift(df, o) for o in ["visit", "conversion"]}
    m["attribution_view"] = {o: attribution_view(df, o, m["lift"][o]) for o in ["visit", "conversion"]}
    m["balance_smd"] = covariate_balance(df)
    m["balance_max_abs_smd"] = max(abs(v) for v in m["balance_smd"].values())
    m["aa_placebo"] = {o: aa_placebo(df, o, a.aa_runs, rng) for o in ["visit", "conversion"]}
    print(f"[{time.time()-t0:.0f}s] lift, attribution view, balance, A/A done")

    sizes = [25_000, 50_000, 100_000, 250_000, 500_000, 1_000_000, 2_000_000]
    holdouts = [0.05, 0.10, 0.15]
    analytic, curve = power_curve(df, "conversion", m["lift"]["conversion"], sizes, holdouts, a.power_sims, rng)
    m["users_needed_80pct_power"] = analytic
    curve.to_csv(f"{a.out}/power_curve.csv", index=False)
    print(f"[{time.time()-t0:.0f}s] power curve done")

    dec, qini, um = uplift_model(df, a.uplift_outcome, a.seed, a.model_rows)
    m["uplift_model"] = {"outcome": a.uplift_outcome, **um}
    dec.to_csv(f"{a.out}/uplift_deciles.csv", index=False)
    qini.to_csv(f"{a.out}/qini.csv", index=False)
    print(f"[{time.time()-t0:.0f}s] uplift model done")

    with open(f"{a.out}/metrics.json", "w") as f:
        json.dump(to_jsonable(m), f, indent=2)
    print(json.dumps(to_jsonable({
        "conv_lift_rel": m["lift"]["conversion"]["lift_rel"],
        "conv_ci_rel": m["lift"]["conversion"]["ci_rel"],
        "visit_lift_rel": m["lift"]["visit"]["lift_rel"],
        "attributed_to_incremental_conv": m["attribution_view"]["conversion"]["attributed_to_incremental_ratio"],
        "users_needed": analytic, "max_smd": m["balance_max_abs_smd"],
        "aa_fpr": {k: v["false_positive_rate"] for k, v in m["aa_placebo"].items()},
        "uplift": um}), indent=2))


if __name__ == "__main__":
    main()
