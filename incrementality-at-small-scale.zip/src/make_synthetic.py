"""SYNTHETIC test data with the Criteo Uplift schema, for testing the pipeline only.
Numbers produced from this file are NOT real findings.

Built-in properties (so every analysis path gets exercised):
  - 85/15 treatment split, random
  - exposure only for treated users, more likely for users with high baseline intent (selection bias)
  - heterogeneous ad effect driven by f0/f3 (so the uplift model has something to find)
"""
import argparse
import numpy as np
import pandas as pd

p = argparse.ArgumentParser()
p.add_argument("--rows", type=int, default=2_000_000)
p.add_argument("--out", default="data/synthetic_uplift.csv.gz")
a = p.parse_args()
rng = np.random.default_rng(0)
n = a.rows

X = rng.normal(size=(n, 12)).astype("float32")
treatment = (rng.random(n) < 0.85).astype("int8")
base = -3.2 + 0.6 * X[:, 1] + 0.4 * X[:, 2]                      # baseline visit intent
p_expose = 1 / (1 + np.exp(-(-3.8 + 0.9 * (base + 3.2))))       # high-intent users get shown ads more
exposure = (treatment * (rng.random(n) < p_expose)).astype("int8")
effect = np.clip(0.5 + 0.8 * X[:, 0] - 0.4 * X[:, 3], -0.3, 2.5)  # persuadability varies by user
logit_v = base + exposure * effect
visit = (rng.random(n) < 1 / (1 + np.exp(-logit_v))).astype("int8")
conversion = (visit * (rng.random(n) < 0.06 + 0.04 * exposure)).astype("int8")

df = pd.DataFrame(X, columns=[f"f{i}" for i in range(12)])
df["treatment"], df["conversion"], df["visit"], df["exposure"] = treatment, conversion, visit, exposure
df.to_csv(a.out, index=False, compression="gzip")
print(f"wrote {n:,} synthetic rows to {a.out}")
