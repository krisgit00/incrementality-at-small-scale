"""Sanity tests for the statistical helpers. Run: python -m pytest tests/ (or python tests/test_stats.py)"""
import sys, os
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from analysis import diff_in_proportions, users_needed


def test_known_values():
    r = diff_in_proportions(60, 1000, 50, 1000)          # 6% vs 5%
    assert abs(r["lift_abs"] - 0.01) < 1e-12
    assert abs(r["lift_rel"] - 0.2) < 1e-12
    se = np.sqrt(0.06 * 0.94 / 1000 + 0.05 * 0.95 / 1000)
    assert abs((r["ci_abs"][1] - r["ci_abs"][0]) - 2 * 1.959964 * se) < 1e-6


def test_null_is_calibrated():
    """Same true rate in both arms: ~5% of tests should be significant at p<0.05."""
    rng = np.random.default_rng(1)
    sig = sum(diff_in_proportions(rng.binomial(20000, .05), 20000, rng.binomial(20000, .05), 20000)["p_value"] < .05
              for _ in range(2000))
    assert 0.035 < sig / 2000 < 0.065


def test_users_needed_matches_simulation():
    """Simulated power at the computed sample size should be ~80%."""
    rng = np.random.default_rng(2)
    p_c, d, h = 0.05, 0.005, 0.5
    n = int(users_needed(p_c, d, h)); n_c = int(n * h); n_t = n - n_c
    hits = sum(diff_in_proportions(rng.binomial(n_t, p_c + d), n_t, rng.binomial(n_c, p_c), n_c)["p_value"] < .05
               for _ in range(2000))
    assert 0.76 < hits / 2000 < 0.84


if __name__ == "__main__":
    for f in [test_known_values, test_null_is_calibrated, test_users_needed_matches_simulation]:
        f(); print("pass", f.__name__)
