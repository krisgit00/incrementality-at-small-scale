"""Ingest the Criteo Uplift dataset (v2.1) into a compact, typed local file.

Source: Criteo AI Lab, "A Large Scale Benchmark for Uplift Modeling" (Diemert et al., 2018).
~14M rows; each row is a user from a randomized incrementality test.
Columns: f0..f11 (anonymized float features), treatment, conversion, visit, exposure.

Usage:
    python src/ingest.py --source data/criteo-research-uplift-v2.1.csv.gz
    python src/ingest.py --source <url-or-path> --sample 2000000   # optional row sample
"""
import argparse
import os
import time

import numpy as np
import pandas as pd

FEATURES = [f"f{i}" for i in range(12)]
FLAGS = ["treatment", "conversion", "visit", "exposure"]
DTYPES = {**{f: "float32" for f in FEATURES}, **{c: "int8" for c in FLAGS}}

DEFAULT_URL = "http://go.criteo.net/criteo-research-uplift-v2.1.csv.gz"


def validate(df: pd.DataFrame) -> None:
    """Fail fast on schema or logic problems before any analysis runs."""
    missing = set(FEATURES + FLAGS) - set(df.columns)
    assert not missing, f"missing columns: {missing}"
    for c in FLAGS:
        bad = ~df[c].isin([0, 1])
        assert not bad.any(), f"{c} has non-binary values"
    assert not df[FEATURES].isna().any().any(), "null features"
    # Logical constraints of the experiment design
    assert (df.loc[df.treatment == 0, "exposure"] == 0).all(), "control users cannot be exposed"


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--source", default=DEFAULT_URL)
    p.add_argument("--out", default="data/criteo_uplift.pkl")
    p.add_argument("--sample", type=int, default=0, help="random row sample size (0 = all)")
    p.add_argument("--seed", type=int, default=42)
    a = p.parse_args()

    t0 = time.time()
    df = pd.read_csv(a.source, dtype=DTYPES)
    if a.sample and a.sample < len(df):
        df = df.sample(n=a.sample, random_state=a.seed).reset_index(drop=True)
    validate(df)

    os.makedirs(os.path.dirname(a.out), exist_ok=True)
    df.to_pickle(a.out)

    conv_no_visit = int(((df.conversion == 1) & (df.visit == 0)).sum())
    print(f"rows={len(df):,}  treated={df.treatment.mean():.1%}  "
          f"visit={df.visit.mean():.2%}  conversion={df.conversion.mean():.3%}  "
          f"exposure(treated)={df.loc[df.treatment == 1, 'exposure'].mean():.2%}  "
          f"conv_without_visit={conv_no_visit}  "
          f"mem={df.memory_usage().sum() / 1e9:.2f}GB  time={time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
