"""Turn analysis outputs into the small files the dashboard reads."""
import json
import pandas as pd

m = json.load(open("outputs/metrics.json"))
rows = []
for o, label in [("conversion", "Conversions"), ("visit", "Visits")]:
    l, a = m["lift"][o], m["attribution_view"][o]
    rows.append({"outcome": o, "label": label,
                 "rate_treated": l["rate_treated"], "rate_control": l["rate_control"],
                 "lift_rel": l["lift_rel"], "ci_low_rel": l["ci_rel"][0], "ci_high_rel": l["ci_rel"][1],
                 "p_value": l["p_value"], "users_treated": l["n_treated"], "users_control": l["n_control"],
                 "attributed": a["attributed_outcomes"], "incremental": round(a["incremental_outcomes"]),
                 "attributed_to_incremental": a["attributed_to_incremental_ratio"]})
pd.DataFrame(rows).to_csv("outputs/dash/lift_views.csv", index=False)

p = pd.read_csv("outputs/power_curve.csv")[["holdout", "users", "share_clear_reads"]]
p.to_csv("outputs/dash/power.csv", index=False)

d = pd.read_csv("outputs/uplift_deciles.csv")
d["ci_low_per_1k"], d["ci_high_per_1k"] = d.ci_low * 1000, d.ci_high * 1000
d[["decile", "users", "incremental_per_1k", "ci_low_per_1k", "ci_high_per_1k", "share_of_incremental"]] \
    .to_csv("outputs/dash/deciles.csv", index=False)

u, un = m["uplift_model"], m["users_needed_80pct_power"]
summary = [{
    "rows": m["rows"], "treated_share": m["treated_share"],
    "exposure_rate": m["attribution_view"]["conversion"]["exposure_rate_treated"],
    "users_needed_5": round(un["5%"]), "users_needed_10": round(un["10%"]), "users_needed_15": round(un["15%"]),
    "top20_share": u["top20_share_of_incremental"], "top30_multiple": u["top30_vs_all_multiple"],
    "top30_per_1k": u["top30_incremental_per_1k"], "all_per_1k": u["all_incremental_per_1k"],
    "learner": "X-learner" if u["learner"] == "x_learner" else "T-learner",
    "qini_x": u["qini_by_learner"]["x_learner"], "qini_t": u["qini_by_learner"]["t_learner"],
    "test_rows": u["test_rows"], "max_smd": m["balance_max_abs_smd"],
    "aa_runs": m["aa_placebo"]["conversion"]["runs"],
    "aa_fpr_conversion": m["aa_placebo"]["conversion"]["false_positive_rate"],
    "aa_fpr_visit": m["aa_placebo"]["visit"]["false_positive_rate"],
}]
json.dump(summary, open("outputs/dash/summary.json", "w"), indent=2)
print(open("outputs/dash/lift_views.csv").read()); print(json.dumps(summary, indent=1))
