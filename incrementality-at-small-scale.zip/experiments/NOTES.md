# Experiment log

Dead ends and stepping stones on the way to the composite estimate. Kept for the record; the
dashboard uses `src/small_holdout.py` and `src/composite.py`. Scripts here import from `src/`, so
run them from the repo root with `PYTHONPATH=src`.

## 2026-11-08

**Starting point.** In `small_holdout.py` the platform benchmark scores ~70% within ±25% at 5K
users, dips to ~50% around 15-40K, then recovers. The early read from visits (surrogate) climbs
steadily but starts low (~25%). Wanted one line that keeps the benchmark's early height and the
early read's climb.

**00_hypotheses_not_run.py.** Pre-registered checks (persuadable-segment targeting, visits as an
early signal, segment stability). Written, never run; superseded by the small-test simulation.

**01_tailored_benchmark.py: benchmark tailored to each advertiser's audience.**
Simulated advertisers as random mixes of 10 baseline-propensity segments so true lifts differ,
with the benchmark built from a separate history slice (Fay-Herriot style shrinkage).
- v1, segment purchase lifts as the benchmark: ~58% flat from 5K to 250K. Benchmark too noisy
  (~40 holdout purchases per segment).
- v2, benchmark from segment visit lift x purchases per visit: no better.
- v3, separate purchases-per-visit for the top segment: starts ~56%, stalls ~64% even at 1M.
  Purchases per incremental visit differ by audience (~0.15 top decile vs ~0.06 elsewhere), so
  one ratio is biased for any single advertiser.
- v4 (file's current state), user-level model of P(purchase | visit): worse (~20%). Ads also lift
  purchases among visitors (6.3% vs 5.3%), which a visits-only surrogate misses. Dropped.
- Also hit two bugs on the way: tied scores collapsed quantile cut points, and ordinal
  tie-breaking grouped holdout users together (the data file is stored in order). Fixed with
  random tie-breaks.

**02_benchmark_miss.py: realistic benchmark error.**
Tried measuring how far a benchmark misses one advertiser, then simulating that miss. Measured
miss came out at 3%, because Criteo advertisers here differ only by audience mix, which the
benchmark captures. With a 3% miss the blend scored 100% everywhere: an artifact, not a result.
Also realized the approach generated the benchmark from the true lift, so its height was set by
an assumption. Dropped. The file's final state is the size-based weighted average that became
`src/composite.py`; `02_benchmark_miss_run.log` is that run.

**Outcome: `src/composite.py`.** Weighted average of the platform-benchmark and early-read
estimates: 50/50 up to 25K users (where the two are about equally accurate), shifting to the
early read alone by 100K. ~44% at 5K, ~60% at 25K, ~82% at 100K, 100% by 600K; no dip. It trades
the benchmark's (flattered) early accuracy for a steady climb.

## Open
- Surrogate standard error ignores uncertainty in the purchases-per-visit ratio (coverage ~84% at
  1M). Add it via the delta method.
- A directional metric ("are ads driving purchases?") plus a zero-effect check would likely suit
  small advertisers better than ±25% accuracy.
