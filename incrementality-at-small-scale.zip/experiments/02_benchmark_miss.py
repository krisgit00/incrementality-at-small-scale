# EXPERIMENT (dropped) - see experiments/NOTES.md. Final state became src/composite.py.
"""Blend a realistic platform benchmark with the early read from visits.

Why: in small_holdout.py the benchmark comes from the same population, so it is nearly perfect,
and the Bayesian estimate dips as weight moves to noisy test data. A real benchmark, built from
other advertisers, misses any one advertiser by some amount. Here that miss is
  1. measured: advertisers with different audience mixes, benchmark built from the history split,
     truth from the experiment pool (same idea as quick_tailored.py);
  2. simulated: each test's benchmark = its true lift x a random miss of that measured size;
  3. used for the weights: the benchmark's uncertainty is set to the same measured miss, so the
     blend weighs each source by how reliable it actually is.
Early read = surrogate (visit lift x purchases per incremental visit, combined with the direct
purchase estimate), as in small_holdout.py.

Sensitivity: a benchmark that misses by 1.5x more than the blend assumes.

Usage: python src/blended_benchmark.py --sims 500
"""
import argparse
import json

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier

from small_holdout import FEATURES, Z, adjusted_diff, surrogate_combined, shrink

K = 10


def segments(x, rng):
    order = np.lexsort((rng.random(len(x)), x))  # sort by score, ties broken at random
    seg = np.empty(len(x), int)
    seg[order] = np.arange(len(x)) * K // len(x)
    return seg


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/criteo_uplift.pkl")
    p.add_argument("--out", default="outputs")
    p.add_argument("--sims", type=int, default=500)
    p.add_argument("--holdout", type=float, default=0.10)
    p.add_argument("--seed", type=int, default=11)
    a = p.parse_args()
    rng = np.random.default_rng(a.seed)

    # Same split and baseline model as small_holdout.py
    df = pd.read_pickle(a.data)
    is_hist = rng.random(len(df)) < 0.30
    hist, pool = df[is_hist], df[~is_hist]
    base = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.1, early_stopping=True,
                                          random_state=a.seed).fit(hist[FEATURES], hist.conversion)
    x_hist = base.predict_proba(hist[FEATURES])[:, 1]
    x_pool = base.predict_proba(pool[FEATURES])[:, 1]

    y_c, y_v, t = pool.conversion.to_numpy(float), pool.visit.to_numpy(float), pool.treatment.to_numpy()
    h_c, h_v, h_t = hist.conversion.to_numpy(float), hist.visit.to_numpy(float), hist.treatment.to_numpy()
    truth, _ = adjusted_diff(y_c, None, t)
    truth_v, _ = adjusted_diff(y_v, None, t)
    prior_mean, _ = adjusted_diff(h_c, None, h_t)
    ratio = prior_mean / adjusted_diff(h_v, None, h_t)[0]

    # 1. Measure the benchmark's miss across advertisers with different audience mixes
    s_h, s_p = segments(x_hist, rng), segments(x_pool, rng)
    bench_k = np.array([adjusted_diff(h_c[s_h == k], None, h_t[s_h == k])[0] for k in range(K)])
    true_k = np.array([adjusted_diff(y_c[s_p == k], None, t[s_p == k])[0] for k in range(K)])
    w = rng.dirichlet(np.ones(K), 5000)
    rel_miss = (w @ bench_k) / (w @ true_k) - 1
    miss = float(1.4826 * np.median(np.abs(rel_miss - np.median(rel_miss))))  # robust sd
    print(f"measured benchmark miss (robust sd, relative): {miss:.3f}")

    # 2-3. Simulated tests, same design as small_holdout.py
    t_idx, c_idx = np.flatnonzero(t == 1), np.flatnonzero(t == 0)
    sizes = [5_000, 10_000, 15_000, 25_000, 40_000, 60_000, 100_000, 150_000, 250_000, 400_000, 600_000, 1_000_000]
    methods = ["naive", "bayes", "visits", "surrogate", "blend"]

    def blend_weight(n):
        """Weight on the platform benchmark estimate: 50/50 up to 25K users, fading (in log size)
        to zero by 100K; from there the early read stands on its own."""
        if n <= 25_000:
            return 0.5
        if n >= 100_000:
            return 0.0
        return 0.5 * (np.log(100_000) - np.log(n)) / (np.log(100_000) - np.log(25_000))
    rows = []
    for n in sizes:
        n_c = int(n * a.holdout)
        rec = {m: [] for m in methods}
        for _ in range(a.sims):
            idx = np.concatenate([rng.choice(t_idx, n - n_c), rng.choice(c_idx, n_c)])
            tt = t[idx]
            e_n, s_n = adjusted_diff(y_c[idx], None, tt)
            e_c, s_c = adjusted_diff(y_c[idx], x_pool[idx], tt)
            e_v, s_v = adjusted_diff(y_v[idx], None, tt)
            e_s, s_s = surrogate_combined(y_c[idx], y_v[idx], x_pool[idx], tt, ratio)
            b, _, _ = shrink(e_c, s_c, prior_mean, abs(prior_mean))
            wb = blend_weight(n)
            e_bl = wb * b + (1 - wb) * e_s
            for m, est in zip(methods, [e_n, b, e_v, e_s, e_bl]):
                rec[m].append(est)
        for m, e in rec.items():
            e, tr = np.array(e), (truth_v if m == "visits" else truth)
            rows.append({"users": n, "method": m,
                         "within_25pct": float(np.mean(np.abs(e - tr) <= 0.25 * tr))})
        print(f"done n={n:,}")

    res = pd.DataFrame(rows)
    res.to_csv(f"{a.out}/blended_benchmark.csv", index=False)
    json.dump({"benchmark_miss_rel_sd": miss, "sims": a.sims, "holdout_share": a.holdout},
              open(f"{a.out}/blended_benchmark_meta.json", "w"), indent=2)
    print(res.pivot(index="users", columns="method", values="within_25pct").round(2)[methods].to_string())


if __name__ == "__main__":
    main()
