"""Build a self-contained copy of the dashboard (docs/index.html) for GitHub Pages.

Inlines the datasets, adds a small stand-in for the dashboard runtime (dash.data / draw / calc),
and defines the design tokens the page uses.

    python tools/build_standalone.py
"""
import csv
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DASH = ROOT / "outputs" / "dash"


def read_csv(p):
    with open(p, newline="") as f:
        return list(csv.DictReader(f))


datasets = {
    "lift": read_csv(DASH / "lift_views.csv"),
    "deciles": read_csv(DASH / "deciles.csv"),
    "small": read_csv(DASH / "small_holdout.csv"),
    "composite": read_csv(ROOT / "outputs" / "composite.csv"),
    "summary": json.loads((DASH / "summary.json").read_text()),
    "smallmeta": json.loads((DASH / "small_meta.json").read_text()),
}

page = (DASH / "index.html").read_text().replace('<meta name="dash-one-writer">\n', "").replace(
    "code available on request", "code in the GitHub repo linked below")

HEAD = """<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Proving Incrementality at Smaller Scale</title>
<meta name="description" content="How small can an incrementality test get and still give a trustworthy answer? Built on Criteo's public randomized ad tests.">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&family=Source+Serif+4:opsz,wght@8..60,400;8..60,500&display=swap">
<script src="https://cdnjs.cloudflare.com/ajax/libs/d3/7.9.0/d3.min.js"></script>
<style>
  :root {
    --font-anthropic-sans: Inter, system-ui, -apple-system, "Segoe UI", sans-serif;
    --font-anthropic-serif: "Source Serif 4", Georgia, serif;
    --cds-font-size-caption: 0.8125rem; --cds-font-size-body: 0.9375rem;
    --cds-font-size-heading: 1.125rem; --cds-font-size-title: 2rem; --cds-font-weight-medium: 500;
    --cds-gap-xs: 0.375rem; --cds-gap-sm: 0.625rem; --cds-gap-md: 1rem; --cds-gap-lg: 1.5rem; --cds-gap-xl: 2.25rem;
    --cds-pad-xs: 0.375rem; --cds-pad-sm: 0.75rem; --cds-pad-lg: 1.25rem; --cds-radius: 8px; --cds-dur-slow: 300ms;
    --color-bg: #fbfaf8; --color-panel: #ffffff; --color-fg: #1f1e1c; --color-fg-muted: #6b6862;
    --color-border-line: #e6e3de; --color-bad: #c2410c;
    --cds-border: #e6e3de; --cds-surface-popover: #ffffff; --cds-shadow-popover: 0 4px 16px rgba(0,0,0,.1);
    --cds-text-secondary: #6b6862; --cds-chart-axis: #cfcac2; --cds-chart-grid: #efece7;
    --cds-chart-muted: #b9b4ab; --cds-chart-reference: #a9a49b;
  }
  @media (prefers-color-scheme: dark) {
    :root {
      --color-bg: #1b1a18; --color-panel: #242320; --color-fg: #f1efea; --color-fg-muted: #a7a39b;
      --color-border-line: #36342f; --cds-border: #36342f; --cds-surface-popover: #2c2b27;
      --cds-shadow-popover: 0 4px 16px rgba(0,0,0,.4); --cds-text-secondary: #a7a39b;
      --cds-chart-axis: #4a4741; --cds-chart-grid: #302e2a; --cds-chart-muted: #6f6b63; --cds-chart-reference: #7c786f;
    }
  }
  html, body { margin: 0; background: var(--color-bg); color: var(--color-fg); }
  body { padding: 2rem 16px 4rem; font-family: var(--font-anthropic-sans); font-size: var(--cds-font-size-body); line-height: 1.5; }
  [hidden] { display: none !important; }
  .tl-card h3 .tl-num { margin-left: 0.35em; }
  .dash-skeleton { background: linear-gradient(90deg, transparent, rgba(127,127,127,.08), transparent); }
  .tl-foot { max-width: 64rem; margin: 3rem auto 0; font-size: var(--cds-font-size-caption); color: var(--color-fg-muted); }
  .tl-foot a { color: inherit; }
</style>
<script>
window.dash = (() => {
  const raw = __DATA__;
  const calcs = {}, draws = {};
  const colors = ['#2f6fd6', '#d9822b', '#2e9d6a', '#9b59b6', '#c0392b', '#7f8c8d'];
  const data = (id) => {
    if (raw[id]) return { status: 'ok', data: raw[id] };
    const c = calcs[id];
    if (!c) return { status: 'error' };
    try { return { status: 'ok', data: c.fn(...c.inputs.map((i) => data(i).data)) }; }
    catch (e) { console.error(id, e); return { status: 'error' }; }
  };
  const run = (name) => document.querySelectorAll(`[data-draw="${name}"]`).forEach((el) => {
    if (el.closest('[hidden]')) return;
    try { draws[name](el); } catch (e) { console.error(name, e); }
  });
  const runAll = () => Object.keys(draws).forEach(run);
  let started = false;
  const draw = (name, fn) => { if (fn) draws[name] = fn; if (started && draws[name]) run(name); };
  const calc = (id, spec) => { calcs[id] = spec; };
  const start = () => {
    started = true; runAll();
    new MutationObserver(runAll).observe(document.body, { subtree: true, attributes: true, attributeFilter: ['hidden'] });
    let w = innerWidth; addEventListener('resize', () => { if (innerWidth !== w) { w = innerWidth; runAll(); } });
  };
  return { data, draw, calc, colors, start };
})();
</script>
</head>
<body>
"""

FOOT = """
<p class="tl-foot">Code and methods: <a href="https://github.com/krisgit00/incrementality-at-small-scale">github.com/krisgit00/incrementality-at-small-scale</a> · Slides: <a href="deck.pdf">deck.pdf</a></p>
<script>dash.start();</script>
</body>
</html>
"""

out = ROOT / "docs" / "index.html"
out.parent.mkdir(exist_ok=True)
out.write_text(HEAD.replace("__DATA__", json.dumps(datasets)) + page + FOOT)
print(f"wrote {out} ({out.stat().st_size / 1024:.0f} KB)")
