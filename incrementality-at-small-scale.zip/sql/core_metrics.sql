-- Core experiment readout in SQL (DuckDB syntax), mirroring src/analysis.py.
-- Run: duckdb -c ".read sql/core_metrics.sql"   (after setting the file path below)

CREATE OR REPLACE VIEW uplift AS
SELECT * FROM read_csv_auto('data/criteo-research-uplift-v2.1.csv.gz');

-- 1) Randomized comparison: true (intent-to-treat) lift
WITH arms AS (
  SELECT treatment,
         COUNT(*)         AS users,
         AVG(visit)       AS visit_rate,
         AVG(conversion)  AS conv_rate
  FROM uplift
  GROUP BY treatment
)
SELECT
  t.users AS treated_users, c.users AS control_users,
  t.conv_rate AS conv_rate_treated, c.conv_rate AS conv_rate_control,
  t.conv_rate - c.conv_rate                         AS conv_lift_abs,
  (t.conv_rate - c.conv_rate) / c.conv_rate         AS conv_lift_rel,
  (t.conv_rate - c.conv_rate) * t.users             AS incremental_conversions
FROM arms t JOIN arms c ON t.treatment = 1 AND c.treatment = 0;

-- 2) Attribution-style comparison: exposed vs not exposed, among treated users only
--    (exposure is NOT randomized, so this mixes ad effect with who gets shown ads)
SELECT exposure,
       COUNT(*)        AS users,
       AVG(conversion) AS conv_rate,
       SUM(conversion) AS conversions
FROM uplift
WHERE treatment = 1
GROUP BY exposure
ORDER BY exposure;
