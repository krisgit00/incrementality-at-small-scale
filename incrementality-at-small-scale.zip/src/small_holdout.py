"""How small can a test get before incrementality estimates stop being trustworthy,
and how much accuracy can better estimators recover below that point?

Setup
  - "Truth" is the randomized lift on the full experiment pool.
  - A separate 30% "history" split stands in for what a platform already knows. It is used
    only to (a) train a baseline model for variance reduction and (b) set a prior.
  - Each simulated advertiser is a random draw of N users from the experiment pool with a
    fixed holdout share. Repeated many times per size.

Estimators compared on every simulated advertiser
  naive    difference in conversion rates between ad-eligible and holdout users
  cupac    the same difference after regression adjustment on a model-predicted baseline
           (CUPED with a model covariate, a.k.a. CUPAC). The covariate uses pre-treatment
           features only, so it cannot absorb the ad effect.
  bayes    cupac estimate shrunk toward a prior built from the history split
           ("borrowing strength"); also gives P(lift > 0), the confidence meter
  visits   naive difference on visits, reported as an early directional signal

Metrics per (size, estimator): median relative error vs truth, share of estimates within
25% and 50% of truth, 95% interval coverage, share of clear positive reads, median interval
width, and for the Bayesian variants, how often P(lift > 0) >= 0.8.

Notes: the holdout share is fixed (default 10%). The prior's width (sd = |history lift|) is a
judgment call; the sensitivity variants test its center, not its width.

Usage: python src/small_holdout.py --sims 1000
"""
import argparse
import json

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import HistGradientBoostingClassifier

FEATURES = [f"f{i}" for i in range(12)]
Z = stats.norm.ppf(0.975)


def adjusted_diff(y, x, t):
    """Treatment-minus-holdout difference in y, regression-adjusted on covariate x.
    Returns (estimate, standard error). With x = None this is the plain difference."""
    if x is not None:
        theta = np.cov(y, x)[0, 1] / np.var(x, ddof=1) if np.var(x) > 0 else 0.0
        y = y - theta * (x - x.mean())
    yt, yc = y[t == 1], y[t == 0]
    nt, nc = len(yt), len(yc)
    est = yt.mean() - yc.mean()
    # Pooled variance: a small holdout with zero events would otherwise get zero variance
    # and an artificially narrow interval.
    pooled_var = ((nt - 1) * yt.var(ddof=1) + (nc - 1) * yc.var(ddof=1)) / (nt + nc - 2)
    se = np.sqrt(pooled_var * (1 / nt + 1 / nc))
    return est, (se if se > 0 else np.inf)  # no events in either arm = no information


def surrogate_combined(y_c, y_v, x, t, ratio):
    """Combine two estimates of the conversion lift:
      (1) surrogate: ratio * visit lift, where ratio = conversions per incremental visit
          learned from history (visits are ~15x more frequent, so this is precise early);
      (2) direct: the regression-adjusted conversion lift.
    The two share users, so they are correlated; weights use the minimum-variance formula
    for two correlated estimators of the same quantity. Returns (estimate, se)."""
    e_d, s_d = adjusted_diff(y_c, x, t)
    e_v, s_v = adjusted_diff(y_v, None, t)
    e_s, s_s = ratio * e_v, abs(ratio) * s_v
    if np.isinf(s_d):
        return e_s, s_s
    tm, cm = t == 1, t == 0
    cov_vc = (np.cov(y_v[tm], y_c[tm])[0, 1] / tm.sum() + np.cov(y_v[cm], y_c[cm])[0, 1] / cm.sum())
    c = ratio * cov_vc                                   # covariance between surrogate and direct estimates
    denom = s_s**2 + s_d**2 - 2 * c
    if not np.isfinite(denom) or denom <= 0:
        return e_s, s_s
    w = (s_d**2 - c) / denom                             # weight on the surrogate
    w = min(max(w, 0.0), 1.0)
    var = w**2 * s_s**2 + (1 - w)**2 * s_d**2 + 2 * w * (1 - w) * c
    return w * e_s + (1 - w) * e_d, np.sqrt(max(var, 1e-18))


def shrink(est, se, prior_mean, prior_sd):
    """Normal-normal posterior for the lift; returns posterior mean, sd and P(lift > 0)."""
    w = 0.0 if np.isinf(se) else prior_sd**2 / (prior_sd**2 + se**2)
    post_mean = w * est + (1 - w) * prior_mean
    post_sd = prior_sd if np.isinf(se) else np.sqrt(w) * se
    return post_mean, post_sd, 1 - stats.norm.cdf(0, post_mean, post_sd)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/criteo_uplift.pkl")
    p.add_argument("--out", default="outputs")
    p.add_argument("--sims", type=int, default=1000)
    p.add_argument("--holdout", type=float, default=0.10)
    p.add_argument("--seed", type=int, default=11)
    a = p.parse_args()
    rng = np.random.default_rng(a.seed)

    df = pd.read_pickle(a.data)
    is_hist = rng.random(len(df)) < 0.30
    hist, pool = df[is_hist], df[~is_hist]

    # Baseline model: predicts conversion from pre-treatment features only (both arms of history)
    base = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.1, early_stopping=True,
                                          random_state=a.seed).fit(hist[FEATURES], hist.conversion)
    x_pool = base.predict_proba(pool[FEATURES])[:, 1]

    y_c, y_v, t = pool.conversion.to_numpy(float), pool.visit.to_numpy(float), pool.treatment.to_numpy()
    truth, _ = adjusted_diff(y_c, None, t)
    truth_v, _ = adjusted_diff(y_v, None, t)

    # Prior from history: centered on its lift, deliberately wide (sd = |lift|)
    prior_mean, _ = adjusted_diff(hist.conversion.to_numpy(float), None, hist.treatment.to_numpy())
    prior_sd = abs(prior_mean)
    # Sensitivity: same width, deliberately wrong centers (no effect expected; effect overstated 2x)
    priors = {"bayes": prior_mean, "bayes_prior_zero": 0.0, "bayes_prior_2x": 2 * prior_mean}

    # Surrogate ratio from history: incremental conversions per incremental visit
    hist_visit_lift, _ = adjusted_diff(hist.visit.to_numpy(float), None, hist.treatment.to_numpy())
    ratio = prior_mean / hist_visit_lift
    # Sensitivity: the ratio understated by half (platform's conversion-per-visit benchmark is off)
    ratios = {"surrogate": ratio, "surrogate_ratio_half": 0.5 * ratio}

    t_idx, c_idx = np.flatnonzero(t == 1), np.flatnonzero(t == 0)
    sizes = [5_000, 10_000, 15_000, 25_000, 40_000, 60_000, 100_000, 150_000, 250_000, 400_000, 600_000, 1_000_000]
    rows = []
    for n in sizes:
        n_c = int(n * a.holdout)
        rec = {k: [] for k in ["naive", "cupac", *priors, *ratios, "visits"]}
        for _ in range(a.sims):
            idx = np.concatenate([rng.choice(t_idx, n - n_c), rng.choice(c_idx, n_c)])
            tt = t[idx]
            e_n, s_n = adjusted_diff(y_c[idx], None, tt)
            e_c, s_c = adjusted_diff(y_c[idx], x_pool[idx], tt)
            e_v, s_v = adjusted_diff(y_v[idx], None, tt)
            rec["naive"].append((e_n, s_n, None))
            rec["cupac"].append((e_c, s_c, None))
            for name, center in priors.items():
                rec[name].append(shrink(e_c, s_c, center, prior_sd))
            for name, r in ratios.items():
                e_s, s_s = surrogate_combined(y_c[idx], y_v[idx], x_pool[idx], tt, r)
                rec[name].append((e_s, s_s, None))
            rec["visits"].append((e_v, s_v, None))

        for name, draws in rec.items():
            tr = truth_v if name == "visits" else truth
            e = np.array([d[0] for d in draws]); s = np.array([d[1] for d in draws])
            row = {"users": n, "holdout_users": n_c, "method": name, "sims": len(draws),
                   "rel_abs_error": float(np.median(np.abs(e - tr)) / tr),
                   "within_25pct": float(np.mean(np.abs(e - tr) <= 0.25 * tr)),
                   "within_50pct": float(np.mean(np.abs(e - tr) <= 0.5 * tr)),
                   "coverage_95": float(np.mean((e - Z * s <= tr) & (tr <= e + Z * s))),
                   "clear_positive": float(np.mean(e - Z * s > 0)),
                   "rel_ci_width": float(np.median(np.where(np.isinf(s), np.nan, 2 * Z * s)) / tr)}
            if name.startswith("bayes"):
                row["confident_share"] = float(np.mean(np.array([d[2] for d in draws]) >= 0.8))
            rows.append(row)
        print(f"done n={n:,}")

    res = pd.DataFrame(rows)
    res.to_csv(f"{a.out}/small_holdout.csv", index=False)

    # Critical point: smallest test size where >= 80% of tests give a clear positive read
    # (log-linear interpolation between grid sizes)
    def critical(g, target=0.8):
        g = g.sort_values("users")
        above = g[g.clear_positive >= target]
        if above.empty:
            return None
        i = g.index.get_loc(above.index[0])
        if i == 0:
            return int(g.users.iloc[0])
        lo, hi = g.iloc[i - 1], g.iloc[i]
        f = (target - lo.clear_positive) / (hi.clear_positive - lo.clear_positive)
        return int(round(np.exp(np.log(lo.users) + f * (np.log(hi.users) - np.log(lo.users)))))

    crit = {m: critical(g) for m, g in res.groupby("method")}
    json.dump({"truth_conversion_lift_abs": truth, "truth_visit_lift_abs": truth_v,
               "prior_mean": prior_mean, "prior_sd": prior_sd, "surrogate_ratio": ratio,
               "holdout_share": a.holdout, "sims": a.sims,
               "monte_carlo_margin_at_50pct": float(Z * np.sqrt(0.25 / a.sims)),
               "critical_users_80pct_clear": crit,
               "notes": {"bayes": "prior built from a history split of the same population, so it is optimistic; "
                                  "across real advertisers it would be set from advertiser-level heterogeneity",
                         "visits": "different metric than conversions; read as speed to a clear directional answer",
                         "surrogate": "conversion lift estimated from visit lift times a history-based conversions-per-"
                                      "incremental-visit ratio, combined with the direct estimate (surrogate index). "
                                      "Ratio comes from the same population, so it is optimistic; assumes the ad's "
                                      "effect on purchases flows mostly through visits"}},
              open(f"{a.out}/small_holdout_meta.json", "w"), indent=2)
    print("critical points:", crit)
    print(res.round(3).to_string(index=False))


if __name__ == "__main__":
    main()
