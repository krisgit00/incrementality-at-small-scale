# EXPERIMENT (dropped) - see experiments/NOTES.md. File is at its last version (v4, user-level surrogate).
"""Quick test: tailored-benchmark estimator (Fay-Herriot style) for small incrementality tests.

Idea: a weighted average of
  (a) a benchmark tailored to the advertiser's audience, built from OTHER advertisers' tests, and
  (b) the test's own early read (surrogate: visits turned into a purchase estimate).
Weights come from precision: weight on the early read = tau^2 / (tau^2 + early-read variance).

Simulated advertisers differ: each one's audience is a random mix of 10 baseline-propensity
segments, so true lifts vary across advertisers.

Splits (no leakage):
  H1 (15%)  segment-level lifts -> the tailored benchmark ("other advertisers' past tests")
  H2 (15%)  calibration tests -> tau^2 (how far advertisers land from their benchmark)
  pool (70%) simulated advertisers and their true lifts

tau floor: real advertisers differ in creative and product, not just audience, so the benchmark
is never trusted to better than +/-25% (tau >= 0.25 * benchmark).

Usage: python src/quick_tailored.py --sims 200
"""
import argparse

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.ensemble import HistGradientBoostingClassifier

from small_holdout import FEATURES, Z, adjusted_diff, surrogate_combined, shrink

K = 10  # audience segments


def seg_lifts(y_c, y_v, t, seg):
    c = np.array([adjusted_diff(y_c[seg == k], None, t[seg == k])[0] for k in range(K)])
    v = np.array([adjusted_diff(y_v[seg == k], None, t[seg == k])[0] for k in range(K)])
    return c, v


def draw(rng, n, w, holdout, idx_t, idx_c):
    """Advertiser with audience mix w: per segment, users split into ad-eligible and holdout."""
    counts = rng.multinomial(n, w)
    parts = []
    for k, m in enumerate(counts):
        m_c = int(round(m * holdout))
        if m - m_c > 0:
            parts.append(rng.choice(idx_t[k], m - m_c))
        if m_c > 0:
            parts.append(rng.choice(idx_c[k], m_c))
    return np.concatenate(parts)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/criteo_uplift.pkl")
    p.add_argument("--out", default="outputs")
    p.add_argument("--sims", type=int, default=200)
    p.add_argument("--holdout", type=float, default=0.10)
    p.add_argument("--tau_floor", type=float, default=0.25)
    p.add_argument("--seed", type=int, default=11)
    a = p.parse_args()
    rng = np.random.default_rng(a.seed)

    df = pd.read_pickle(a.data)
    u = rng.random(len(df))
    h1, h2, pool = df[u < 0.15], df[(u >= 0.15) & (u < 0.30)], df[u >= 0.30]

    base = HistGradientBoostingClassifier(max_iter=200, early_stopping=True, random_state=a.seed)
    base.fit(h1[FEATURES], h1.conversion)

    # Two-part model: P(purchase | visited, profile, ad arm), fit on H1 visitors.
    # The test measures visit lift; history supplies how the ad also lifts purchases per visitor
    # (a pure surrogate would miss that part; see the check printed below).
    vis1 = h1[h1.visit == 1]
    pmod = HistGradientBoostingClassifier(max_iter=200, early_stopping=True, random_state=a.seed)
    pmod.fit(vis1[FEATURES + ["treatment"]], vis1.conversion)
    print("P(purchase | visit): ad-eligible %.4f, holdout %.4f"
          % tuple(vis1.groupby("treatment").conversion.mean().loc[[1, 0]]))

    def prep(d):
        x = base.predict_proba(d[FEATURES])[:, 1]
        order = np.lexsort((rng.random(len(x)), x))     # sort by score, ties broken at random
        seg = np.empty(len(x), int)
        seg[order] = np.arange(len(x)) * K // len(x)     # equal-size segments
        v = d.visit.to_numpy(float)
        z = v * pmod.predict_proba(d[FEATURES + ["treatment"]])[:, 1]  # predicted purchase from the visit
        return d.conversion.to_numpy(float), z, d.treatment.to_numpy(), x, seg, v

    c1, z1, t1, _, s1, _ = prep(h1)
    _, bench_c_k = seg_lifts(c1, z1, t1, s1)  # benchmark purchase lift by segment, via the surrogate index
    glob_c = adjusted_diff(c1, None, t1)[0]   # one platform-wide benchmark (for comparison)

    def estimate(yc, z, x, t, w):
        e, s = surrogate_combined(yc, z, x, t, 1.0)
        return e, s, w @ bench_c_k

    # Calibrate tau on H2: past tests of 250K users each
    c2, v2, t2, x2, s2, _ = prep(h2)
    it2 = [np.flatnonzero((s2 == k) & (t2 == 1)) for k in range(K)]
    ic2 = [np.flatnonzero((s2 == k) & (t2 == 0)) for k in range(K)]
    rel_dev, rel_var = [], []
    for _ in range(200):
        w = rng.dirichlet(np.ones(K))
        i = draw(rng, 250_000, w, a.holdout, it2, ic2)
        e, s, bc = estimate(c2[i], v2[i], x2[i], t2[i], w)
        rel_dev.append((e - bc) / bc); rel_var.append((s / bc) ** 2)
    tau_rel_dl = float(np.sqrt(max(np.var(rel_dev) - np.mean(rel_var), 0.0)))  # DerSimonian-Laird style
    tau_rel = max(tau_rel_dl, a.tau_floor)
    print(f"tau (relative): DL estimate {tau_rel_dl:.3f}, used {tau_rel:.3f}")

    cp, zp, tp, xp, sp, vp = prep(pool)
    pool_c_k, pool_v_k = seg_lifts(cp, vp, tp, sp)
    itp = [np.flatnonzero((sp == k) & (tp == 1)) for k in range(K)]
    icp = [np.flatnonzero((sp == k) & (tp == 0)) for k in range(K)]

    sizes = [5_000, 10_000, 15_000, 25_000, 40_000, 60_000, 100_000, 150_000, 250_000, 400_000, 600_000, 1_000_000]
    rows = []
    for n in sizes:
        rec = {m: [] for m in ["naive", "visits", "platform_benchmark", "surrogate", "tailored", "tailored_off_bench"]}
        for _ in range(a.sims):
            w = rng.dirichlet(np.ones(K))
            truth, truth_v = w @ pool_c_k, w @ pool_v_k
            i = draw(rng, n, w, a.holdout, itp, icp)
            yc, yv, z, x, t = cp[i], vp[i], zp[i], xp[i], tp[i]
            e_n, s_n = adjusted_diff(yc, None, t)
            e_v, s_v = adjusted_diff(yv, None, t)
            e_c, s_c = adjusted_diff(yc, x, t)
            pb, pb_sd, _ = shrink(e_c, s_c, glob_c, abs(glob_c))
            rec["visits"].append((e_v, s_v, truth_v))
            rec["platform_benchmark"].append((pb, pb_sd, truth))
            e_s, s_s, bc = estimate(yc, z, x, t, w)
            post, sd, _ = shrink(e_s, s_s, bc, tau_rel * abs(bc))
            # Sensitivity: benchmark misses this advertiser by a random ~30% (unmodeled differences)
            bc_off = bc * np.exp(rng.normal(0, 0.3))
            post_off, sd_off, _ = shrink(e_s, s_s, bc_off, tau_rel * abs(bc_off))
            for m, (e, s) in {"naive": (e_n, s_n), "surrogate": (e_s, s_s),
                              "tailored": (post, sd), "tailored_off_bench": (post_off, sd_off)}.items():
                rec[m].append((e, s, truth))
        for m, d in rec.items():
            e, s, tr = (np.array(col) for col in zip(*d))
            rows.append({"users": n, "method": m,
                         "within_25pct": float(np.mean(np.abs(e - tr) <= 0.25 * tr)),
                         "coverage_95": float(np.mean(np.abs(e - tr) <= Z * s))})
        print(f"done n={n:,}")

    res = pd.DataFrame(rows)
    res.to_csv(f"{a.out}/quick_tailored.csv", index=False)
    print(res.pivot(index="users", columns="method", values="within_25pct").round(2).to_string())


if __name__ == "__main__":
    main()
