# EXPERIMENT (never run) - see experiments/NOTES.md.
"""Pre-registered hypothesis tests: can incrementality insight shorten the path to proof?

Criteria were fixed before running:
  H2 supported if the top-30% persuadable segment needs <= 50% of the users the full population needs.
  H3 supported if visits need <= 1/3 of the users conversions need AND decile rank correlation
     between visit uplift and conversion uplift is >= 0.7.
  H4 supported if uplift scores from models trained on disjoint halves correlate >= 0.7 (Spearman),
     top-30% membership overlaps >= 70%, and the top segment's lift beats the average in both test halves.
"""
import json
import time

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.model_selection import train_test_split

from analysis import diff_in_proportions, users_needed, fit_scores

SEED, OUT = 7, "outputs"
t0 = time.time()
df = pd.read_pickle("data/criteo_uplift.pkl")
d = df.sample(n=6_000_000, random_state=SEED)
train, test = train_test_split(d, test_size=0.5, random_state=SEED, stratify=d.treatment)
test = test.copy()
res = {"criteria": {"H2_max_ratio": 0.5, "H3_max_ratio": 1 / 3, "H3_min_rank_corr": 0.7,
                    "H4_min_score_corr": 0.7, "H4_min_top30_overlap": 0.7}}


def lift(g, y):
    t, c = g[g.treatment == 1], g[g.treatment == 0]
    return diff_in_proportions(t[y].sum(), len(t), c[y].sum(), len(c))


# Main model on the full training half (visits, X-learner) -> held-out scores
test["score"] = fit_scores(train, test, "visit", SEED)["x_learner"]
cut = test.score.quantile(0.7)
top = test[test.score >= cut]
print(f"[{time.time()-t0:.0f}s] main model scored")

# ---------- H2: does focusing on persuadable users shorten the path to proof? ----------
H = 0.10
h2 = {}
for y in ["conversion", "visit"]:
    a, s = lift(test, y), lift(top, y)
    na = users_needed(a["rate_control"], a["lift_abs"], H)
    ns = users_needed(s["rate_control"], s["lift_abs"], H) if s["lift_abs"] > 0 else float("inf")
    h2[y] = {"all_rate_control": a["rate_control"], "all_lift_abs": a["lift_abs"], "all_lift_rel": a["lift_rel"],
             "top30_rate_control": s["rate_control"], "top30_lift_abs": s["lift_abs"], "top30_lift_rel": s["lift_rel"],
             "top30_ci_abs": s["ci_abs"], "users_needed_all": na, "users_needed_top30": ns, "ratio": ns / na}
h2["supported"] = h2["conversion"]["ratio"] <= res["criteria"]["H2_max_ratio"]
res["H2"] = h2

# ---------- H3: are visits a faster, consistent early signal? ----------
a_v, a_c = lift(test, "visit"), lift(test, "conversion")
n_v = users_needed(a_v["rate_control"], a_v["lift_abs"], H)
n_c = users_needed(a_c["rate_control"], a_c["lift_abs"], H)
test["decile"] = pd.qcut(test.score.rank(method="first", ascending=False), 10, labels=range(1, 11))
dec = pd.DataFrame([{"decile": int(k), "visit_uplift": lift(g, "visit")["lift_abs"],
                     "conv_uplift": lift(g, "conversion")["lift_abs"]} for k, g in test.groupby("decile", observed=True)])
rho = stats.spearmanr(dec.visit_uplift, dec.conv_uplift).statistic
res["H3"] = {"users_needed_visit": n_v, "users_needed_conversion": n_c, "ratio": n_v / n_c,
             "decile_rank_corr": float(rho), "deciles": dec.to_dict("records"),
             "supported": (n_v / n_c <= res["criteria"]["H3_max_ratio"]) and (rho >= res["criteria"]["H3_min_rank_corr"])}
print(f"[{time.time()-t0:.0f}s] H2, H3 done")

# ---------- H4: are segment insights stable? ----------
tr_a, tr_b = train_test_split(train, test_size=0.5, random_state=SEED + 1, stratify=train.treatment)
s_a = fit_scores(tr_a, test, "visit", SEED)["x_learner"]
s_b = fit_scores(tr_b, test, "visit", SEED)["x_learner"]
corr = stats.spearmanr(s_a, s_b).statistic
top_a, top_b = s_a >= np.quantile(s_a, 0.7), s_b >= np.quantile(s_b, 0.7)
overlap = (top_a & top_b).sum() / top_a.sum()
half = np.random.default_rng(SEED).random(len(test)) < 0.5
halves = []
for name, m in [("half_1", half), ("half_2", ~half)]:
    g = test[m]
    halves.append({"half": name, "all_visit_lift": lift(g, "visit")["lift_abs"],
                   "top30_visit_lift": lift(g[g.score >= cut], "visit")["lift_abs"]})
wins = all(h["top30_visit_lift"] > h["all_visit_lift"] for h in halves)
res["H4"] = {"score_rank_corr": float(corr), "top30_overlap": float(overlap), "halves": halves, "top_wins_both": wins,
             "supported": corr >= res["criteria"]["H4_min_score_corr"] and overlap >= res["criteria"]["H4_min_top30_overlap"] and wins}
print(f"[{time.time()-t0:.0f}s] H4 done")


def clean(o):
    if isinstance(o, dict): return {k: clean(v) for k, v in o.items()}
    if isinstance(o, list): return [clean(v) for v in o]
    if isinstance(o, (np.floating, np.integer)): return o.item()
    if isinstance(o, np.bool_): return bool(o)
    return o


json.dump(clean(res), open(f"{OUT}/hypotheses.json", "w"), indent=2)
print(json.dumps(clean({k: res[k] for k in ["H2", "H3", "H4"]}), indent=1)[:4000])
