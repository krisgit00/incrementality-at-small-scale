"""Composite estimate for small tests: platform benchmark early, early read from visits later.

Weights by test size: 50/50 up to 25K users (where the two are about equally accurate in
small_holdout.py), shifting in log size to the early read alone by 100K.

Runs the same simulation design as small_holdout.py (same split, baseline model and estimators)
so all four lines on the chart come from one set of simulated tests.

    python src/composite.py --sims 1000
"""
import argparse

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier

from small_holdout import FEATURES, adjusted_diff, surrogate_combined, shrink

SIZES = [5_000, 10_000, 15_000, 25_000, 40_000, 60_000, 100_000, 150_000, 250_000, 400_000, 600_000, 1_000_000]


def benchmark_weight(n, lo=25_000, hi=100_000):
    if n <= lo:
        return 0.5
    if n >= hi:
        return 0.0
    return 0.5 * np.log(hi / n) / np.log(hi / lo)


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--data", default="data/criteo_uplift.pkl")
    p.add_argument("--out", default="outputs/composite.csv")
    p.add_argument("--sims", type=int, default=1000)
    p.add_argument("--holdout", type=float, default=0.10)
    p.add_argument("--seed", type=int, default=11)
    a = p.parse_args()
    rng = np.random.default_rng(a.seed)

    df = pd.read_pickle(a.data)
    is_hist = rng.random(len(df)) < 0.30
    hist, pool = df[is_hist], df[~is_hist]
    base = HistGradientBoostingClassifier(max_iter=200, learning_rate=0.1, early_stopping=True,
                                          random_state=a.seed).fit(hist[FEATURES], hist.conversion)
    x = base.predict_proba(pool[FEATURES])[:, 1]

    y_c, y_v, t = pool.conversion.to_numpy(float), pool.visit.to_numpy(float), pool.treatment.to_numpy()
    truth = adjusted_diff(y_c, None, t)[0]
    truth_v = adjusted_diff(y_v, None, t)[0]
    h_t = hist.treatment.to_numpy()
    prior = adjusted_diff(hist.conversion.to_numpy(float), None, h_t)[0]
    ratio = prior / adjusted_diff(hist.visit.to_numpy(float), None, h_t)[0]

    t_idx, c_idx = np.flatnonzero(t == 1), np.flatnonzero(t == 0)
    rows = []
    for n in SIZES:
        n_c = int(n * a.holdout)
        w = benchmark_weight(n)
        est = {m: [] for m in ["naive", "bayes", "visits", "surrogate", "composite"]}
        for _ in range(a.sims):
            i = np.concatenate([rng.choice(t_idx, n - n_c), rng.choice(c_idx, n_c)])
            ti = t[i]
            e_c, s_c = adjusted_diff(y_c[i], x[i], ti)
            bench = shrink(e_c, s_c, prior, abs(prior))[0]
            early = surrogate_combined(y_c[i], y_v[i], x[i], ti, ratio)[0]
            est["naive"].append(adjusted_diff(y_c[i], None, ti)[0])
            est["bayes"].append(bench)
            est["visits"].append(adjusted_diff(y_v[i], None, ti)[0])
            est["surrogate"].append(early)
            est["composite"].append(w * bench + (1 - w) * early)
        for m, e in est.items():
            tr = truth_v if m == "visits" else truth
            rows.append({"users": n, "method": m, "within_25pct": np.mean(np.abs(np.array(e) - tr) <= 0.25 * tr)})
        print(f"n={n:,} done")

    res = pd.DataFrame(rows)
    res.to_csv(a.out, index=False)
    print(res.pivot(index="users", columns="method", values="within_25pct").round(2).to_string())


if __name__ == "__main__":
    main()
